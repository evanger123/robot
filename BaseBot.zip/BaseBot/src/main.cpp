/*----------------------------------------------------------------------------*/
/*                                                                            */
/*    Module:       main.cpp                                                  */
/*    Author:       C:\Users\ehuang                                           */
/*    Created:      Tue Jul 26 2022                                           */
/*    Description:  V5 project                                                */
/*                                                                            */
/*----------------------------------------------------------------------------*/

// ---- START VEXCODE CONFIGURED DEVICES ----
// Robot Configuration:
// [Name]               [Type]        [Port(s)]
// rightMotor           motor         1               
// leftMotor            motor         2               
// arm                  motor         3               
// Controller1          controller                    
// ---- END VEXCODE CONFIGURED DEVICES ----

#include "vex.h"

using namespace vex;

void moveDistance(float dist)
{
  rightMotor.setVelocity(100, percent);
  leftMotor.setVelocity(100, percent);
  rightMotor.spinFor(forward, dist*135, degrees, false);
  leftMotor.spinFor(forward, dist*135, degrees, true);
}

void pointTurnDegrees(float deg, bool dir) {

  //true = left turn, false = right turn


  rightMotor.setVelocity(100, percent);
  leftMotor.setVelocity(100, percent);

  if(dir) {
    rightMotor.spinFor(forward, deg*11.25*5/4.125, degrees, false);
    leftMotor.spinFor(reverse, deg*11.25*5/4.125, degrees, true);
  } else {
    rightMotor.spinFor(reverse, deg*11.25*5/4.125, degrees, false);
    leftMotor.spinFor(forward, deg*11.25*5/4.125, degrees, true);
  }
}

int main() {
  // Initializing Robot Configuration. DO NOT REMOVE!

  vexcodeInit();
  for (int i = 0; i<4; i++)
  {

    moveDistance(12);
    pointTurnDegrees(90, false);
  
  }
}
